package Hackethon.IdentifyNewBikes;

import org.testng.annotations.Test;

import Hackethon.IdentifyNewBikes.Base.DriverSetup;
import Hackethon.IdentifyNewBikes.Pages.FindNewBikes;
import Hackethon.IdentifyNewBikes.Pages.LoginPage;
import Hackethon.IdentifyNewBikes.Pages.UsedCars;
import Hackethon.IdentifyNewBikes.utils.ExtentReport;

import org.testng.annotations.BeforeClass;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class NewTest extends DriverSetup {
//	public static WebDriver driver;

	DriverSetup setup = new DriverSetup();
	FindNewBikes findNewBikes = new FindNewBikes();
	LoginPage loginPage = new LoginPage();
	UsedCars usedCars = new UsedCars();

	@Test(priority = 1, groups = "Smoke")
	public void FirstTestCase() throws Exception {
		findNewBikes.searchUpcomingBikes();
		findNewBikes.searchHondaBikes();
		findNewBikes.searchHondaBikesUnder4Lakh();
	}

	@Test(priority = 2, groups = "Regression")
	public void SecondTestCase() throws Exception {
		usedCars.UsedCarsChennai();
		usedCars.PopularModels();
	}

	@Test(priority = 3, groups = "Smoke")
	public void ThirdTestCase() throws Exception {
		loginPage.loginPage();
	}

	@BeforeClass(alwaysRun = true)
	public void beforeClass() {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter 1 for Chrome...\nEnter 2 for Edge...");
			int options = sc.nextInt();
			setup.driverSetup(options);
			setup.getURL();
			sc.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@AfterClass(alwaysRun = true)
	public void afterClass() {
		try {
			ExtentReport.Flush();
			setup.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
